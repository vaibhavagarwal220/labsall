//#ifndef MY_FUN_H
//#def MY_FUN_H
#include <stdio.h>
#include <stdlib.h>
void josephus(int ,int ,int *);
int deque(int*,int);
void enque(int *,int,int);
int* create(int);
int* init(int);
//#endif